// Passport.js auth setup goes here
